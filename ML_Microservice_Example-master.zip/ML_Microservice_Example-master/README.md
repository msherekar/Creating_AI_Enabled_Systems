# ML_Microservice_Example
Example code to build microservice to return learning stats and provide inference

Provides two microservices
1) returns performance stats - http://localhost:8786/stats
2) returns inference determination given an age and salary - http://localhost:8786/infer?age=45&salary=40000

## Design Outline in Design.ipynb
Populate throughout for your final project

